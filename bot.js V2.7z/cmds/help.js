const Commands = require("../core/classes.js")
const fetch = require('node-fetch')
const Discord = require('discord.js');
class w extends Commands {

}

module.exports = function setup(bot) {
    commands = new w(bot, "classname")
        //function名稱就是指令名稱
        //指令寫法
    commands.command(function w(msg, ...text) {
        msg.channel.send(text.join(" "))
    }, aliases = ["ee", "ww"])

    //commands.bot等於bot or client
    commands.command(function e(msg) {
            return commands.bot
        })
        //event用法
    commands.listener(function message(msg) {
        console.log(msg.content)
    })
    commands.command(function bs(message, nubmer, ...text) {
            if (parseFloat(nubmer).toString() !== "NaN" && Number(nubmer) <= 1000) {
                if (text.join(" ") === "") {
                    message.channel.send("請輸入主題")
                    return
                }
                let jjson = JSON.stringify({ "Topic": text.join(" "), "MinLen": Number(nubmer) })
                fetch("https://api.howtobullshit.me/bullshit", { method: 'POST', body: jjson }).then(function(w) {
                    return w.text()
                }).then(function(w) {
                    e = w.replace(/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/g, "")
                    c = e.replace(/<br>/g, "\n")
                    let embed = new Discord.MessageEmbed();
                    embed.setTitle("唬爛產生器")
                    embed.setDescription(`主題:\`${text.join(" ")}\`\n內容:\`\`\`fix\n${c}\n\`\`\``)
                    embed.setFooter(text = message.author.tag, iconURL = message.author.avatarURL())
                    message.channel.send(embed)
                })
            } else {
                message.channel.send("請輸入小於1000的整數")
            }
        })
        //group用法
    let e = commands.group(function wq(msg) {
        console.log(msg.content)
    })

    e.command(function rr(msg, x) {
        console.log(x)
    })
    e.command(function ww(msg, ...y) {
        console.log(y)
    })

    bot.AddCog(commands)
}